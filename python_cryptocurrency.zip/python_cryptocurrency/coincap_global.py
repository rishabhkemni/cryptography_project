import json
import requests
global_url = "https://api.coinmarketcap.com/v2/global/"

req = requests.get(global_url)
res = req.json()
print(json.dumps(res,sort_keys=True,indent=4))

active_curr = res['data']['active_cryptocurrencies']
print(active_curr)
active_markets = res['data']['active_markets']
bitcoin_percentage = res['data']['bitcoin_percentage_of_market_cap']
last_updated = res['data']['last_updated']
global_cap = res['data']['quotes']['USD']['total_market_cap']
global_vol = res['data']['quotes']['USD']['total_volume_24h']
print("There are currently active currencies",active_curr)
print("Active markets are ",active_markets)
print("The global cap of all cryptocurrencies is ",global_cap)
print("24 global cap volume is ",global_vol)
print("Total percentage of global capital is ",bitcoin_percentage)
print("information last update on ",last_updated)
