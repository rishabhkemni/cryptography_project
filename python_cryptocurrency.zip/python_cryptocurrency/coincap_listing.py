import json
import requests

listing_url = 'https://api.coinmarketcap.com/v2/listings/'

req = requests.get(listing_url)
res = request.json()

#print(json.dumps(res, sort_keys=True, indent=4))

data = res['data']

for curr in data:
    rank = curr['id']
    name = curr['name']
    symbol = curr['symbol']
    print(str(rank) + ': ' + name + ' (' + symbol + ')')
